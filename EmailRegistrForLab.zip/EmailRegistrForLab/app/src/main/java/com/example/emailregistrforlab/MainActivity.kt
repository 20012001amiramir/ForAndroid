import android.R
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.support.v
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : ActionBarActivity() {
    // Объявляем об использовании следующих объектов:
    private var username: EditText? = null
    private var password: EditText? = null
    private var login: Button? = null
    private var loginLocked: TextView? = null
    private var attempts: TextView? = null
    private var numberOfAttempts: TextView? = null

    // Число для подсчета попыток залогиниться:
    var numberOfRemainingLoginAttempts = 3
    protected fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Связываемся с элементами нашего интерфейса:
        username = findViewById(R.id.edit_user) as EditText?
        password = findViewById(R.id.edit_password) as EditText?
        login = findViewById(R.id.button_login) as Button?
        loginLocked = findViewById(R.id.login_locked) as TextView?
        attempts = findViewById(R.id.attempts) as TextView?
        numberOfAttempts = findViewById(R.id.number_of_attempts) as TextView?
        numberOfAttempts!!.text = Integer.toString(numberOfRemainingLoginAttempts)
    }

    // Обрабатываем нажатие кнопки "Войти":
    fun Login(view: View?) {

        // Если введенные логин и пароль будут словом "admin",
        // показываем Toast сообщение об успешном входе:
        if (username!!.text.toString() == "admin" && password!!.text
                .toString() == "admin"
        ) {
            Toast.makeText(
                ApplicationProvider.getApplicationContext(),
                "Вход выполнен!",
                Toast.LENGTH_SHORT
            ).show()

            // Выполняем переход на другой экран:
            val intent = Intent(this@MainActivity, Second::class.java)
            ContextCompat.startActivity(intent)
        } else {
            Toast.makeText(
                ApplicationProvider.getApplicationContext(),
                "Неправильные данные!",
                Toast.LENGTH_SHORT
            ).show()
            numberOfRemainingLoginAttempts--

            // Делаем видимыми текстовые поля, указывающие на количество оставшихся попыток:
            attempts!!.visibility = View.VISIBLE
            numberOfAttempts!!.visibility = View.VISIBLE
            numberOfAttempts!!.text = Integer.toString(numberOfRemainingLoginAttempts)

            // Когда выполнено 3 безуспешных попытки залогиниться,
            // делаем видимым текстовое поле с надписью, что все пропало и выставляем
            // кнопке настройку невозможности нажатия setEnabled(false):
            if (numberOfRemainingLoginAttempts == 0) {
                login!!.isEnabled = false
                loginLocked!!.visibility = View.VISIBLE
                loginLocked!!.setBackgroundColor(Color.RED)
                loginLocked!!.text = "Вход заблокирован!!!"
            }
        }
    }
}