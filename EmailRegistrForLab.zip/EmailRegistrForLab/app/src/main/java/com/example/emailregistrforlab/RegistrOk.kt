package com.example.emailregistrforlab

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.app.Activity;

class RegistrOk : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registr_ok)
    }
}

